This is a beta build for macOS, to run the program you will need to install Python 3.9 and if you want to also numpy

To run the benchmark just unzip the zip file, enter the directory and type

./PYPrime 2B 7 (to run in 2B mode and complete 7 iterations)